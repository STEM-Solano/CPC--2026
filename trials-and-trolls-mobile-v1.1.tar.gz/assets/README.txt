Trials and Trolls 1.1 - mobile-ready source

Files:
main.py - Pygame/Pygbag source
images/ - all seven character sprites
music/ - six encounter tracks

On Windows, install Pygbag: python -m pip install pygbag
Build (replace the path with your extracted folder):
python -m pygbag --build --ume_block 0 "C:\path\to\Trials-and-Trolls-Mobile-v1.1"

Publish: copy the CONTENTS of build\web (including index.html, .apk, .tar.gz, favicon) to the ROOT of your GitHub repository CPC--2026. Keep GitHub Pages set to main / (root). Do NOT upload source files instead of the built website.

Mobile: touch handling supports FINGERDOWN and MOUSEBUTTONDOWN. The main loop yields to the browser each frame. Safari audio may require a tap to unlock and depends on browser support.
